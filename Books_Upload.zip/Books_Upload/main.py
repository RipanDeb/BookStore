from flask import Flask, jsonify, request, abort
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import relationship, backref
from fetchrecomendation import process
from flask_httpauth import HTTPBasicAuth


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:iamadmin@localhost/ripanbookstore'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
auth = HTTPBasicAuth()


USERS = {
    "admin": "ripan123",
    "user": "deb123"
}


@auth.verify_password
def verify_password(username, password):
    """Verify the username and password."""
    if username in USERS and USERS[username] == password:
        return username

@app.route('/secure-data')
@auth.login_required
def get_secure_data():
    return jsonify({"message": "This is protected message."})


# Book model
class Book(db.Model):
    __tablename__ = 'books'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    title = db.Column(db.String(255), nullable=False)
    author = db.Column(db.String(255), nullable=False)
    genre = db.Column(db.String(255), nullable=False)
    year_published = db.Column(db.Integer, nullable=False)
    summary = db.Column(db.Text, nullable=True)

    reviews = relationship('Review', backref='book', cascade='all, delete-orphan')


    def __init__(self, title, author, genre, year_published, summary=None):
        self.title = title
        self.author = author
        self.genre = genre
        self.year_published = year_published
        self.summary = summary

# Review model
class Review(db.Model):
    __tablename__ = 'reviews'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    book_id = db.Column(db.Integer, db.ForeignKey('books.id'), nullable=False)
    user_id = db.Column(db.Integer, nullable=False)
    review_text = db.Column(db.Text, nullable=False)
    rating = db.Column(db.Integer, nullable=False)

    def __init__(self, book_id, user_id, review_text, rating):
        self.book_id = book_id
        self.user_id = user_id
        self.review_text = review_text
        self.rating = rating


# GET /books: Retrieve all books
@app.route('/books', methods=['GET'])
def get_books():
    books = Book.query.all()
    return jsonify([{'id': book.id, 'title': book.title, 'author': book.author, 'summary': book.summary} for book in books])


# POST /books: Add a new book with all columns
@app.route('/books', methods=['POST'])
def add_book():
    data = request.json
    new_book = Book(title=data['title'], author=data['author'], year_published=data['year_published'], genre=data['genre'], summary=data.get('summary'))
    db.session.add(new_book)
    db.session.commit()
    return jsonify({'message': 'Book added successfully'}), 201


# GET /books/<id>: Retrieve a specific book by its ID
@app.route('/books/<string:book_id>', methods=['GET'])
def get_book(book_id):
    book = Book.query.get(book_id)
    if not book:
        abort(404)
    return jsonify({'id': book.id, 'title': book.title, 'author': book.author, 'summary': book.summary})


# PUT /books/<id>: Update a book's information by its ID
@app.route('/books/<string:book_id>', methods=['PUT'])
def update_book(book_id):
    data = request.json
    book = Book.query.get(book_id)
    if not book:
        abort(404)
    book.title = data.get('title', book.title)
    book.author = data.get('author', book.author)
    book.summary = data.get('summary', book.summary)
    db.session.commit()
    return jsonify({'message': 'Book updated successfully'})


# DELETE /books/<id>: Delete a book by its ID
@app.route('/books/<string:book_id>', methods=['DELETE'])
def delete_book(book_id):
    book = Book.query.get(book_id)
    if not book:
        abort(404)
    db.session.delete(book)
    db.session.commit()
    return jsonify({'message': 'Book deleted successfully'})

# POST /books/<id>/reviews: Add a review for a book
@app.route('/books/<string:book_id>/reviews', methods=['POST'])
def add_review(book_id):
    data = request.json
    new_review = Review(book_id=book_id, user_id=data['user_id'], review_text=data['review_text'], rating=data['rating'])
    db.session.add(new_review)
    db.session.commit()
    return jsonify({'message': 'Review added successfully'}), 201

# GET /books/<id>/reviews: Retrieve all reviews for a book
@app.route('/books/<string:book_id>/reviews', methods=['GET'])
def get_reviews(book_id):
    reviews = Review.query.filter_by(book_id=book_id).all()
    if not reviews:
        abort(404)
    return jsonify([{'id': review.id, 'user_id': review.user_id, 'review_text': review.review_text, 'rating': review.rating} for review in reviews])

# GET /books/<id>/summary: Get a summary and aggregated rating for a book
@app.route('/books/<string:book_id>/summary', methods=['GET'])
def get_summary(book_id):
    book = Book.query.get(book_id)
    if not book:
        abort(404)
    reviews = Review.query.filter_by(book_id=book_id).all()
    total_reviews = len(reviews)
    if total_reviews == 0:
        average_rating = 0
    else:
        total_rating = sum(review.rating for review in reviews)
        average_rating = total_rating / total_reviews
    summary = {
        'title': book.title,
        'author': book.author,
        'total_reviews': total_reviews,
        'average_rating': average_rating
    }
    return jsonify(summary)

# GET /recommendations: Get book recommendations based Book ID entered by USER
@app.route('/recommendations/<string:book_id>', methods=['GET'])
def get_recommendations(book_id):
    book = Book.query.get(book_id)
    if not book:
        abort(404)
    else:
        reviews = Review.query.filter_by(book_id=book_id).all()
        total_reviews = len(reviews)
        if total_reviews == 0:
            average_rating = 0
        else:
            total_rating = sum(review.rating for review in reviews)
            average_rating = total_rating / total_reviews

        new_book = {
            'Title': book.title,
            'Genre': book.genre,
            'AverageRating': average_rating
        }

        recomendation = process(new_book)
        return jsonify({'Recomemended_Books for': recomendation})


if __name__ == '__main__':
    app.run(debug=True)
