import pandas as pd

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import MinMaxScaler
from sklearn.neighbors import NearestNeighbors
import joblib


books_df = pd.read_csv('Dataset/books_dataset.csv')

# TF-IDF Vectorization for Genre
tfidf = TfidfVectorizer(stop_words='english')
genre_matrix = tfidf.fit_transform(books_df['Genre'])

# Scale Average Rating
scaler = MinMaxScaler()
average_rating_scaled = scaler.fit_transform(books_df['AverageRating'].values.reshape(-1, 1))

# Combine genre_matrix and scaled average_rating
combined_matrix = genre_matrix.multiply(average_rating_scaled)

#Training the model
knn = NearestNeighbors(n_neighbors=5, metric='cosine')
knn.fit(combined_matrix)

# Save the model and transformers
joblib.dump(knn, 'model_pickle/book_recommender_knn_model.pkl')
joblib.dump(tfidf, 'model_pickle/book_recommender_tfidf.pkl')
joblib.dump(scaler, 'model_pickle/book_recommender_scaler.pkl')
print("Models Prepared")


