import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import MinMaxScaler
from sklearn.neighbors import NearestNeighbors
import joblib
import pandas as pd


booksdatabase_df = pd.read_csv('Dataset/books_dataset.csv')


def load_model():
    knn = joblib.load('model_pickle/book_recommender_knn_model.pkl')
    tfidf = joblib.load('model_pickle/book_recommender_tfidf.pkl')
    scaler = joblib.load('model_pickle/book_recommender_scaler.pkl')
    return knn, tfidf, scaler

def get_recommendations(input_data, knn, tfidf, scaler):
    
    # Prepare the feature vector for the book
    genre_vector = tfidf.transform([input_data['Genre']])
    scaled_rating = scaler.transform([[input_data['AverageRating']]])
    combined_features = genre_vector.multiply(scaled_rating)

    # Find the nearest neighbors
    distances, indices = knn.kneighbors(combined_features)
    recommended_books = [booksdatabase_df.iloc[i]['Title'] for i in indices[0] if booksdatabase_df.iloc[i]['Title'] != input_data['Title']]
    
    return recommended_books


def process(new_book):
    knn, tfidf, scaler = load_model()
    recommended_books = get_recommendations(new_book, knn, tfidf, scaler)
    print(recommended_books)
    return recommended_books
